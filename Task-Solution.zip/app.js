
/* Json Object */
var comments = [
	{
	  name: "Vito Corleone",
	  comment: "I'm gonna make him an offer he can't refuse.",
	  timestamp: "69379200"
	},
	{
	  name: "Terry Benedict",
	  comment: "Congratulations... You're a dead man!",
	  timestamp: "1007683200"
	},
	{
	  name: "Jessica Rabbit",
	  comment: "I'm not bad. I'm just drawn that way.",
	  timestamp: "583113600"
	},
	{
	  name: "Martin Brody",
	  comment: "You're gonna need a bigger boat.",
	  timestamp: "172281600"
	},
	{ name: "The Joker", comment: "Why so serious..?", timestamp: "1215993600" }
  ];
  
  $(document).ready(function() {
	const commentsListHtml = comments.map(item => {
	  const timeStamp = parseInt(item.timestamp);
	  const newDate = new Date(timeStamp * 1000);
	  return `<li class="list-group-item">
		  <p>"${item.comment}"</p>
		  <span class="font-weight-bold">- ${item.name}</span><span>
		  ${newDate}</span>
	  </li>`;
	});
  
	$("#comments").append(commentsListHtml);
  });
  